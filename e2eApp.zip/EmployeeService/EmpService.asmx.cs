﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using DataAccessLib;
using EntitiesLib;

namespace EmployeeService
{
    /// <summary>
    /// Summary description for EmpService
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class EmpService : System.Web.Services.WebService
    {

        [WebMethod]
        public void AddEmployee(EmployeeEntity emp)
        {
            var component = DBFactory.GetComponent();
            component.AddEmployee(emp);
        }
        [WebMethod]
        public void UpdateEmployee(EmployeeEntity emp)
        {
            var component = DBFactory.GetComponent();
            component.UpdateEmployee(emp);
        }
        [WebMethod]
        public EmployeeEntity GetDetails(int id)
        {
            var component = DBFactory.GetComponent();
            return component.GetDetails(id);
        }
        [WebMethod]
        public EmployeeEntity[] GetEmployees(string name)
        {
            var component = DBFactory.GetComponent();
            return component.GetDetails(name);
        }

    }
}
