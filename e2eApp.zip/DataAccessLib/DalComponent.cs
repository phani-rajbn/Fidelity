﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using EntitiesLib;
namespace DataAccessLib
{
    public interface IDalComponent
    {
        void AddEmployee(EmployeeEntity emp);
        void UpdateEmployee(EmployeeEntity emp);
        EmployeeEntity GetDetails(int id);
        EmployeeEntity[] GetDetails(string name);
    }

    public static class DBFactory
    {
        public static IDalComponent GetComponent()
        {
            var type = ConfigurationManager.AppSettings["Component"];
            if(type.ToLower() == "linq")
            {
                return new DalComponent();
            }
            throw new Exception("Not the expected type");
        }
    }
    class DalComponent : IDalComponent
    {
        public void AddEmployee(EmployeeEntity emp)
        {
            var context = new EmpDBDataContext();
            context.Employees.InsertOnSubmit(new Employee { EmpID = emp.EmpID, EmpName = emp.EmpName, EmpAddress = emp.EmpAddress, EmpSalary = emp.EmpSalary, DeptId = emp.DeptId });
            context.SubmitChanges();
        }

        public EmployeeEntity GetDetails(int id)
        {
            var context = new EmpDBDataContext();
            var emp = context.Employees.FirstOrDefault((e) => e.EmpID == id);
            return new EmployeeEntity { EmpID = emp.EmpID, EmpName = emp.EmpName, EmpAddress = emp.EmpAddress, EmpSalary = emp.EmpSalary, DeptId = emp.DeptId };
        }

        public EmployeeEntity[] GetDetails(string name)
        {
            var context = new EmpDBDataContext();
            var data=  context.Employees.Where((e) => e.EmpName.Contains(name)).Select((emp)=> new EmployeeEntity { EmpID = emp.EmpID, EmpName = emp.EmpName, EmpAddress = emp.EmpAddress, EmpSalary = emp.EmpSalary, DeptId = emp.DeptId }).ToArray();
            return data;
        }

        public void UpdateEmployee(EmployeeEntity emp)
        {
            var context = new EmpDBDataContext();
            var selected = context.Employees.FirstOrDefault((e) => e.EmpID == emp.EmpID);
            selected.DeptId = emp.DeptId;
            selected.EmpName = emp.EmpName;
            selected.EmpAddress = emp.EmpAddress;
            selected.EmpSalary = emp.EmpSalary;
            context.SubmitChanges();
        }
    }
}
